import React, { useState, useRef, useEffect, useMemo } from "react";
import { createPortal } from "react-dom";

interface OptionProps {
  className?: string;
  options: string[];
  label: string;
  value?: string | string[];
  onChange?: (selected: string) => void;
  error?: string;
  isSearchable?: boolean;
  isMulti?: boolean;
}

const DROPDOWN_MAX_HEIGHT = 224; // matches max-h-56 (14rem)

export default function SingleSelect({
  className,
  options,
  label,
  value,
  onChange,
  error,
  isSearchable = false,
}: OptionProps) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [dropUp, setDropUp] = useState(false);
  const [coords, setCoords] = useState<{
    left: number;
    width: number;
    top?: number;
    bottom?: number;
  }>({ left: 0, width: 0 });

  const containerRef = useRef<HTMLDivElement>(null);
  const dropdownRef = useRef<HTMLUListElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  const displayValue = Array.isArray(value) ? value.join(", ") : value;

  // Close dropdown on outside click.
  // The dropdown is portaled to <body>, so it's NOT a descendant of
  // containerRef anymore — must also check dropdownRef, or every click
  // on an option/search box gets treated as "outside" and closes it
  // before the option's own onClick fires.
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as Node;
      const clickedInsideContainer = containerRef.current?.contains(target);
      const clickedInsideDropdown = dropdownRef.current?.contains(target);

      if (!clickedInsideContainer && !clickedInsideDropdown) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Focus search input
  useEffect(() => {
    if (open && isSearchable) {
      setSearch("");
      setTimeout(() => searchInputRef.current?.focus(), 0);
    }
  }, [open, isSearchable]);

  // Shared position calculation, used both on open and on scroll/resize
  const updatePosition = () => {
    const el = containerRef.current;
    if (!el) return;

    const rect = el.getBoundingClientRect();
    const spaceBelow = window.innerHeight - rect.bottom;
    const spaceAbove = rect.top;
    const shouldDropUp = spaceBelow < DROPDOWN_MAX_HEIGHT && spaceAbove > spaceBelow;

    setDropUp(shouldDropUp);
    setCoords({
      left: rect.left,
      width: rect.width,
      ...(shouldDropUp
        ? { bottom: window.innerHeight - rect.top + 4, top: undefined }
        : { top: rect.bottom + 4, bottom: undefined }),
    });
  };

  // Recalculate on scroll/resize while open
  useEffect(() => {
    if (!open) return;

    window.addEventListener("scroll", updatePosition, true);
    window.addEventListener("resize", updatePosition);

    return () => {
      window.removeEventListener("scroll", updatePosition, true);
      window.removeEventListener("resize", updatePosition);
    };
  }, [open]);

  // Toggle handler: computes coords BEFORE opening, in the same event,
  // so open + coords land in the same render — no left:0 flash on first open.
  const toggleOpen = () => {
    if (!open) updatePosition();
    setOpen((prev) => !prev);
  };

  const handleSelect = (option: string) => {
    onChange?.(option);
    setOpen(false);
  };

  const displayedOptions = useMemo(() => {
    if (!isSearchable) return options;
    return options.filter((opt) =>
      opt.toLowerCase().includes(search.toLowerCase())
    );
  }, [options, search, isSearchable]);

  const isLabelFloating = Boolean(displayValue) || open;

  const dropdown = (
    <ul
      ref={dropdownRef}
      style={{
        position: "fixed",
        left: coords.left,
        width: coords.width,
        top: coords.top,
        bottom: coords.bottom,
      }}
      className={`bg-white max-sm:dark:bg-[var(--color-childbgdark)] max-sm:dark:text-white shadow-lg border border-gray-300 max-sm:dark:border-gray-800 rounded-md max-h-56 overflow-auto
      transition-[opacity,transform] duration-200 z-[9999] ${dropUp ? "origin-bottom" : "origin-top"}
      ${
        open
          ? "opacity-100 scale-100 pointer-events-auto"
          : "opacity-0 scale-95 pointer-events-none"
      }`}
    >
      {isSearchable && (
        <li className="sticky top-0 bg-white max-sm:dark:bg-[var(--color-childbgdark)] p-2 border-b z-10">
          <input
            ref={searchInputRef}
            type="text"
            placeholder="Search..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full px-2 py-1 border rounded-md text-sm outline-none focus:border-[var(--color-primary)]"
          />
        </li>
      )}

      {displayedOptions.length > 0 ? (
        displayedOptions.map((opt, idx) => (
          <li
            key={idx}
            onClick={() => handleSelect(opt)}
            className="px-3 py-2 hover:bg-gray-100 cursor-pointer truncate"
          >
            {opt}
          </li>
        ))
      ) : (
        <li className="px-3 py-2 text-gray-500 text-sm">
          {isSearchable ? "No matching results" : "No options available"}
        </li>
      )}
    </ul>
  );

  return (
    <div
      ref={containerRef}
      className={`relative w-full ${className}`}
      style={{ minWidth: "170px" }}
    >
      {/* Label */}
      <label
        className={`absolute z-10 left-3 transition-all duration-200 px-1 bg-white max-sm:dark:bg-[var(--color-childbgdark)] max-sm:dark:text-gray-400 pointer-events-none
        ${
          isLabelFloating
            ? "-top-2 text-xs text-[var(--color-primary)]"
            : "top-3 text-gray-500 text-sm"
        }`}
      >
        {label}
      </label>

      {/* Select box */}
      <div
        onClick={toggleOpen}
        className={`w-full border rounded-md px-3 py-2 cursor-pointer bg-white max-sm:dark:bg-[var(--color-childbgdark)] max-sm:dark:text-white flex justify-between items-center
        ${
          error
            ? "border-red-500"
            : "border-gray-400 max-sm:dark:border-gray-700"
        } transition-colors`}
        style={{ minHeight: "3rem" }}
      >
        <span
          className={`${
            displayValue
              ? "text-gray-900 max-sm:dark:text-gray-300"
              : "text-gray-400"
          } truncate`}
        >
          {displayValue || ""}
        </span>

        <svg
          className={`w-4 h-4 text-gray-500 transition-transform ${
            open ? "rotate-180" : ""
          }`}
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          viewBox="0 0 24 24"
        >
          <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
        </svg>
      </div>

      {/* Dropdown, portaled to <body> so it can never be trapped behind a sibling's stacking context */}
      {typeof document !== "undefined" && createPortal(dropdown, document.body)}

      {/* Error */}
      {error && <p className="text-red-500 text-sm mt-1">{error}</p>}
    </div>
  );
}